# SIGIL TRINITY — Operations Playbook

**Product:** Sigil Trinity
**Price:** $44 (intro code TRINITYSPARK = 30% off → $30.80)
**Delivery SLA:** 72 hours
**Repo:** thefirstspark/sigilcraft (existing)
**Subdomain:** sigilcraft.thefirstspark.shop

---

## FILES IN THIS PACKAGE

| File | Goes to | Purpose |
|---|---|---|
| `sigil-trinity.html` | `sigilcraft/sigil-trinity.html` | Public sales page → drives Whop checkout |
| `forge-success.html` | `sigilcraft/forge-success.html` | Post-purchase intake form (set as Whop redirect) |
| `template-trinity.html` | Master template | Duplicate & personalize per customer |

---

## DEPLOYMENT (one-time setup)

1. **Push these three files** to the `thefirstspark/sigilcraft` repo root
2. **Create a Whop product** called "Sigil Trinity" at $44
   - Set `success_url` to: `https://sigilcraft.thefirstspark.shop/forge-success.html`
   - Add promo code `TRINITYSPARK` for 30% off
3. **Link from main site:** add a CTA card on `sigilcraft.thefirstspark.shop/index.html` pointing to `/sigil-trinity.html`
4. **Cross-promote:** add a "Next: Forge Your Sigils →" card at the bottom of every Soul Map page

---

## THE DELIVERY FLOW (per customer)

When a Web3Forms email lands:

### Step 1 — Generate filename
- Customer name: e.g. **Sarah Marie Lee** + birth date **05/19/1988**
- Filename: `sml05191988`
- Folder path: `/sigilcraft/[filename]/index.html`
- Vanity URL: `https://sigilcraft.thefirstspark.shop/sml05191988/`

### Step 2 — Forge the three sigils
Use the existing forge tool at `sigilcraft.thefirstspark.shop/forge` to generate three SVGs:
- One from the intention text + name letters
- One from the protection text + name letters
- One from the manifestation text + birth coordinates

Save each as both PDF (white background, print-ready) and PNG (transparent).

### Step 3 — Personalize the template
Copy `template-trinity.html` and replace these tokens:

| Token | Replace with |
|---|---|
| `{{CUSTOMER_NAME}}` | Full name |
| `{{CUSTOMER_FIRST_NAME}}` | First name only |
| `{{FORGE_DATE}}` | Today's date (e.g. "05.07.2026") |
| `{{INITIALS}}` | Lowercase initials (e.g. "sml") |
| `{{BIRTH_MMDDYYYY}}` | Birth date as 8 digits |
| `{{BIRTH_LOCATION}}` | City, state (or "—" if not provided) |
| `{{INTENTION_QUOTE}}` | Their intention text (lightly edited for poetry) |
| `{{PROTECTION_QUOTE}}` | Their protection text |
| `{{MANIFESTATION_QUOTE}}` | Their manifestation text |

Replace the three placeholder `<svg>` blocks with the actual forged sigils.

### Step 4 — Push to GitHub
```
/sigilcraft/sml05191988/
  ├── index.html  (the personalized template)
  └── assets/
      ├── sml05191988-intention.pdf
      ├── sml05191988-intention.png
      ├── sml05191988-protection.pdf
      ├── sml05191988-protection.png
      ├── sml05191988-manifestation.pdf
      └── sml05191988-manifestation.png
```

Update the main `sigilcraft/index.html` library section to add a new entry (only if you want it discoverable; otherwise keep customer URLs unlisted).

### Step 5 — Send delivery email
Subject: `🔥 Your Sigil Trinity is forged.`

```
[Customer first name],

The forge is complete. Your trinity lives here:

→ https://sigilcraft.thefirstspark.shop/sml05191988/

Three sigils. Forged from your name, your moment, your words.
PDFs and PNGs are linked on the page — print them, save them, carry them.

The 7-day activation protocol is included. Don't skip Day 7.

You'll know they're working when the patterns shift.

— Kate
The First Spark
```

---

## AUTOMATION PATH (post-launch)

Once the manual flow is proven (5-10 deliveries), fork the existing `soul-map-webhook.mjs` Netlify function:

1. Duplicate as `sigil-trinity-webhook.mjs`
2. Swap the template path
3. Update the email body
4. Hook to a new Resend route
5. Token replacement happens automatically from Web3Forms payload

This is a 1-2 hour build once you're ready.

---

## TRACKING

**GA4 events firing:**
- `click_cta_hero` — landing page top CTA
- `click_cta_investment` — landing page price-block CTA
- `purchase_complete` — fires on intake form load (proxy for Whop conversion)
- `intake_submitted` — successful form submission

**Web3Forms key:** `a9396dce-718b-4a34-a66d-b0e9ac5dc919`
**GA4 ID:** `G-FPHDDHSCWS`

---

## CROSS-SELL HOOKS (do these after launch)

1. **Soul Map → Sigil Trinity:** Add a footer card on every Soul Map page: *"You've seen the terrain. Now forge the tools."* → links to `/sigil-trinity.html`
2. **Sigil Trinity → Players Lounge:** On the delivered vanity page, add a soft mention: *"Want unlimited sigil forging? The Players Lounge unlocks the full grimoire."*
3. **Email follow-up at 30 days:** Light-touch email asking how the sigils are working + offering a Soul Map at member discount

---

## NEXT TIER (Q3 2026 idea)

If Sigil Trinity sells well, ladder up to:
- **Sigil Grimoire** ($88) — 5 sigils + ritual binding ceremony PDF + audio activation
- **Sigil Year** ($222) — monthly forged sigil for 12 months, delivered the first of each month

Don't build these until Trinity has 25+ orders.
